#include <stdio.h>
int main()
{
    printf("Codigo ASCII do A eh: %d\n",'A');
    printf("Codigo ASCII do B eh: %d\n",'B');
    return 0;
}