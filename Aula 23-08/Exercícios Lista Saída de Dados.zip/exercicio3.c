#include <stdio.h>
int main()
{
    printf("%03d\n",7);
    printf("%03d\n",17);
    printf("%03d",1024);
    return 0;
}