#include <stdio.h>

int main()
{
    printf("Oi! Esse eh um programa de teste!\n");
    printf("*\n");
    printf("***\n");
    printf("*****\n");
    printf("Oi! Esse eh um programa de teste!\n");
    printf("   *\n");
    printf("  ***\n");
    printf(" *****\n");
    return 0;
}