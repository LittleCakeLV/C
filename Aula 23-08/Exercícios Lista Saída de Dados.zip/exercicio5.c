#include <stdio.h>
int main()
{
    printf("%c\n",'A'+32);
    printf("%c\n",'B'+32);
    printf("%c\n",'C'+32);
    printf("%c\n",'D'+32);
    return 0;
}